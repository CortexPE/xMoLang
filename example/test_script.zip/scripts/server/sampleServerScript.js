let sampleServerSystem = server.registerSystem(0, 0);

sampleServerSystem.initialize = function() {
	//server.log("test");
	this.listenForEvent("minecraft:entity_death", eventData => this.onEntityDeath(eventData));
	this.listenForEvent("mod:client_entered_world", eventData => this.onClientEnteredWorld(eventData));
	this.listenForEvent("mod:click", eventData => this.onClick(eventData));
};

sampleServerSystem.onEntityDeath = function (eventData) {
	this.broadcastEvent("minecraft:display_chat_event", "test2");
}

sampleServerSystem.onClientEnteredWorld = function (eventData) {
    this.broadcastEvent("minecraft:display_chat_event", "test3");
};

sampleServerSystem.onClick = function (eventData) {
    this.broadcastEvent("minecraft:display_chat_event", "test77 " + eventData);
};