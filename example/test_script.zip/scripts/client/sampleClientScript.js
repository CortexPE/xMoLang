const aClientSystem = client.registerSystem(0, 0);

var welcomeMessage = "";

// Setup which events to listen for
aClientSystem.initialize = function () {
    this.listenForEvent("minecraft:client_entered_world", (eventData) => this.onClientEnteredWorld(eventData));
	this.listenForEvent("mod:show_message", (eventData) => this.onShowMessage(eventData));
	this.listenForEvent("minecraft:ui_event", (eventData) => this.onUIMessage(eventData));
};

aClientSystem.onClientEnteredWorld = function (eventData) {
	aClientSystem.broadcastEvent("mod:client_entered_world", eventData);
};

aClientSystem.onShowMessage = function (eventData) {
	welcomeMessage = eventData;
	aClientSystem.broadcastEvent("minecraft:load_ui", {path:"mod_menu.html"});
};

aClientSystem.onUIMessage = function (eventData) {
	
	eventData = JSON.parse(eventData);
	let eventName = eventData.name;
	eventData = eventData.data;
	
	if(eventName === "mod:ui_ready") {
		let uiEventData = {
			eventName: "ShowWelcomeMessage",
			data: JSON.stringify(welcomeMessage)
		};
	
		// Send the event to the custom screen
		this.broadcastEvent("minecraft:send_ui_event", uiEventData);
	}
	else if(eventName === "mod:click") {
		this.broadcastEvent("mod:click", eventData);
		this.broadcastEvent("minecraft:unload_ui", {path:"mod_menu.html"});
	}
};